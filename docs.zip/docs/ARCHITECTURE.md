# ERC Volunteer Service Portal — Architecture

Status: Phase 3 (SPA scaffold + containerization). Target runtime: Node LTS (API images = Node 24 Alpine), Postgres 16.

## 1. High-level topology

```
SPA (React + TS + Vite) ── :5173 ──┐              Phase 3
                                   ├──> API (Node LTS + Express) :4000
Browser                             │              │
  ├ session cookie (erc.sid) ───────┤              ├─ Postgres 16 (sessions,
  └ CSRF cookie (erc.csrf) ─────────┘              │   domain data, audit log)
├─ Redis 7 (+ BullMQ later)
                                                    └─ MinIO (registration documents)
```

The SPA runs containerized (`web/Dockerfile`, `vite preview`). Its `/api`
requests go through a **same-origin dev proxy** to the API container
(`ERC_PREVIEW_PROXY_TARGET`, default `http://app:4000` when wired in compose)
so session/CSRF cookies stay same-site — no CORS surface is introduced for the
SPA at any stage.

Compose (`docker-compose.yml`): `postgres`, `redis`, `minio` always up for dev;
`app` and `web` are behind the `app` profile (`docker compose --profile app up -d --build`).

## 2. Layering (server)

Routes → middlewares → controllers → services → repositories → Prisma/DB.

```
src/
  config/        env parsing + fail-fast prod checks
  lib/           prisma, logger, http (ApiError), password (Argon2id),
                 csrf (double-submit), rateLimit, session
  middleware/    error, validate (zod), auth (requireAuth / requireOwnership /
                 requireBranchScope)
  modules/<domain>/  routes, controller, service, repository, schemas
  routes/        root apiRouter (/health + per-module routers)
  types/         express-session augmentations
  index.ts       bootstrap + graceful shutdown
```

Rules inherited from the spec (kept for the whole project):

- Only **approved** service-time records count toward a volunteer's totals.
- Add/edit time **requests** may carry an optional `assignedAdminId`; admin
  placement/credentials are the request lifecycle, approval creates/edits the
  official record inside one transaction, and a second approval of the same
  request is a no-op (partial-unique indexes + transactional status flip).
- Admin direct time changes require a `reason` (zod + DB CHECK).
- Audit log is **append-only** (UPDATE/DELETE/TRUNCATE all blocked by triggers).
- Onboarding completion is computed server-side from actual field/document
  validity; it may never report 100% while required data is missing.
- Server-side search + pagination; reports/QR docs carry opaque tokens only.

## 3. Request lifecycle (middleware order, `buildApp`)

```
helmet → cors(credentials=true) → express.json(1mb) → cookieParser()
      → sessionMiddleware (connect-pg-simple, Postgres store)
      → '/api' + doubleCsrfProtection   (all mutating /api requests)
      → apiRouter → notFoundHandler → errorHandler
```

CSRF: double-submit. `getSessionIdentifier: () => ''` deliberately — the token is
NOT bound to the session id so it survives session regeneration at login;
mutation then requires the header token to HMAC-match the cookie value.
Cookie is `httpOnly` + `SameSite=Lax`, `secure` in prod, `__Host-` name in prod,
`Max-Age` matches the session lifetime.

Sessions: Postgres store (`session` table, no memory fallback), 7-day max age,
`rolling: true`, session id is regenerated on login (fixation mitigation).

## 4. Authentication

- Login (`POST /api/auth/login`): identifier = admin **username** or volunteer
  **code**. Volunteer codes are upper-cased. Timing-equalized miss path
  (precomputed dummy Argon2id hash) defeats username enumeration by response
  time; identical generic 401 for wrong-password vs unknown-user.
- Passwords: Argon2id, OWASP params (m=19456, t=2, p=1), 32-byte salt via
  `@node-rs/argon2` (NAPI — ABI-stable across Node 20/24/25, musl prebuilds for
  Alpine).
- Session shape (`SessionActor`): `{ role, userId, branchId, isHq, ... }`.
  `role` is a coarse `admin | volunteer`; `role`/`isHq`/`branchId` drive the
  three authorization middlewares.
- Rate limiting: `express-rate-limit` (20 / 15 min on login, 5 / 15 min on
  register) with `express-slow-down` v2 (constant 300 ms after 5) — slow-down
  runs before the hard limit.

## 5. Authorization (middleware contract)

| Middleware              | Grants when                                                            | Fails closed on        |
| ----------------------- | ---------------------------------------------------------------------- | ---------------------- |
| `requireAuth(role?)`    | authenticated session, optionally role-matched (403 if wrong role)     | 401 no session         |
| `requireOwnership(fn)`  | volunteer requesting their own resource; admins pass (scope governs)   | 403 forged owner id    |
| `requireBranchScope(fn)`| HQ admin (bypass) or branch_admin whose `branchId` equals the target   | 403 missing/mismatched branch |

Every Phase-2+ endpoint must compose these (no UI-only hiding). `branch_id` is
NOT NULL on all resource tables, so a well-formed query always yields a scope
target; the middleware still fails closed when one is absent.

## 6. Database constraints

Hand-written migration `20260917002639_db_check_constraints` adds what Prisma's
DSL cannot express. Prisma models keep those columns `String`; PostgreSQL CHECKs
are the source of truth:

- roles: `admins.role IN ('branch_admin','hq_admin')` + branch-scope rule
  (branch_admin MUST have branch, hq_admin MUST NOT).
- lifecycles: registrations `pending|approved|rejected`; volunteers
  `approved|rejected` (volunteers are created only from approved registrations,
  so `pending` volunteers do not exist); documents & requests
  `pending|approved|rejected`; email format regex on registrations/volunteers.
- signs: `service_time_records.minutes <> 0` (signed, legitimately negative for
  official subtractions), add/edit requests `> 0`; `time_add_requests.minutes`,
  `time_edit_requests.requested_minutes` positive.
- required text: non-blank `event`, non-blank audit `action`, non-blank
  `reason` on edit requests and admin adjustments.
- exactly-one-owner on documents: volunteer XOR registration (`(a::int)+(b::int)=1`).
- partial unique indexes: at most one `pending` add request per
  (volunteer,date,event,minutes); at most one `pending` edit per record.

Append-only audit: `trg_audit_logs_append_only` (BEFORE UPDATE OR DELETE) and
`trg_audit_logs_no_truncate` (BEFORE TRUNCATE). Test/DBA cleanup disables the
TRUNCATE guard only with DB TRIGGER privilege (see `tests/helpers.ts`).

## 7. Security control inventory → docs/SECURITY.md

Headers (helmet), CSRF double-submit, server-side sessions in Postgres, argon2id,
login slow-down + hard limit, input validation at every endpoint (zod), DB-level
CHECKs as the last line, audit log, branch scoping, prod fail-fast on weak
secrets, `.dockerignore` + multi-stage images (Node 24 LTS Alpine,
production-only deps).

## 8. Registration & approval workflow (Phase 2a)

```
POST /api/volunteer/register            public; registerLimiter (5/15 min); zod
                                        full-resolve; 201 pending registration
                                        (branch exists + active, email unique)
GET  /api/admin/registrations           requireAuth('admin') → branch-scoped
                                        queue: page/pageSize≤100/search
                                        (name|email|code, SQL ILIKE)
GET  /api/admin/registrations/:id       scoped detail (or 404)
POST /api/admin/registrations/:id/approve  scoped + allowed-state; tx:
                                        registration→approved,
                                        Volunteer created (code ERC-<n+1>,
                                        starts ERC-1001; me=<n> concurrency-safe
                                        SELECT FOR UPDATE), email-verification
                                        token issued (sha256 digest row),
                                        audit "REGISTRATION_APPROVED" in-tx.
                                        P2002 collision → retry (5×).
POST /api/admin/registrations/:id/reject   scoped + allowed-state; tx: state +
                                        reason audit ("REGISTRATION_REJECTED").
POST /api/volunteer/verify-email       public; verifyLimiter (20/1h default);
                                        sha256(token) match → row deleted
                                        (single use), volunteer emailVerifiedAt
                                        set; replay/expired → 400.
POST /api/volunteer/resend-verification  requireAuth('volunteer'); re-issues
                                        + burns all previous tokens in-tx.
```

All mutating endpoints are behind the global double-submit CSRF (section 3).
Branch scoping is enforced in the **service layer** (throws 403
`BRANCH_SCOPE_VIOLATION`) — `requireBranchScope` middleware cannot express the
HQ/null pass-through in a single resource lookup, so the service owns it.
Registration outputs exclude `passwordHash`; the raw verification token is
**never** returned or persisted — only its sha256 digest (Section 7/SECURITY).

Volunteer codes are derived from a monotonic "last code" column (`next_int`)
with `SELECT ... FOR UPDATE` inside the approval transaction; approval is
impossible without a volunteer row, and a second judge of the same registration
gets 409 `REGISTRATION_ALREADY_DECIDED`.

Approval also emits the email-verification link. Three delivery modes in
`lib/mailer.ts`: SMTP (`SMTP_*`) in real deployments; a buffered in-memory
stream transport in tests (`lastCapturedMail()`); a log-only fallback in dev
(never production — SECURITY.md). Resend re-issues + burns old tokens through
the same path.

## 9. Registration documents + presigned retrieval (Phase 2b)

```
POST   /api/registrations/:registrationId/documents   public; CSRF header works
        (multer memory, 5 MB cap, MIME allowlist, 20/15min); pending
        registration required (else 409 REGISTRATION_DECIDED); field "file" +
        text fields "category" (photo|id_document|certificate|other) and
        "applicationAccessToken" (possession proof — see below);
        DB row first, MinIO putObject (key registrations/{registrationId}/{uuid}),
        row rolled back if the object write fails; audit document.uploaded.
DELETE /api/registrations/:registrationId/documents/:documentId
        applicant's own pending document only (409 DECIDED otherwise); JSON body
        field "applicationAccessToken" required; row deleted, object
        removeObject best-effort; audit document.deleted.
GET    /api/admin/registrations/:id/documents          admin, branch-scoped;
        optional `?category=` filter; never exposes objectKey.
POST   /api/admin/documents/:documentId/approve        admin, scoped; reviewable
        only while pending (409 DOCUMENT_ALREADY_REVIEWED); audit
        document.approved.
POST   /api/admin/documents/:documentId/reject         admin, scoped; note
        required; audit document.rejected.
GET    /api/admin/documents/:documentId/download-url   admin, scoped; pre-signed
        URL (expiresInSeconds, default 5 min); bucket stays private.
```

Ownership model: an uploaded document is bound to the registration
(`exactly-one-owner` CHECK, section 6) and inherits its branch. Admin actions
resolve scope from the document's own branch row (403 `BRANCH_SCOPE_VIOLATION`
on mismatch, HQ passes). The decision endpoints guard against reviewing an
already-reviewed document (409 `DOCUMENT_ALREADY_REVIEWED`).

Application-access token (Phase 3 close-out): `registerVolunteer` issues 32
random bytes and stores only the sha256 digest (`application_access_tokens`,
same pattern as email-verification); the raw token is emailed as
`${PUBLIC_HOST}/application/{registrationId}/documents?token=…` and never
persisted or returned by an endpoint. Every public upload/delete verifies it
(DISTINCT 403 codes for missing / invalid / consumed / expired).
Single-use is lifecycle-scoped — one token per registration, burned in the
approve/reject transaction (so post-decision reuse is 409 `REGISTRATION_DECIDED`),
but NOT per request, so one emailed link can attach multiple documents.
See SECURITY.md for the rationale.

## 10. Frontend (Phase 3) + data not modeled yet

The SPA lives in `web/` (React + TS + Vite). API access goes through
`web/src/api/client.ts`, which always fetches a CSRF token first and replays it
as `x-csrf-token` on mutations; on 401 the session is cleared client-side.
i18n: i18next with inline `en`/`ar` resources and a sync `localStorage` +
`navigator` detector; the `<html lang/dir>` attributes are applied from the
resolved `init()` promise (i18next v26 can resolve synchronously and never
re-emits the boot language — see IMPLEMENTATION_PLAN / i18n boot regression
test). Auth pages (`/login`, `/register`) and the placeholder dashboard
(`/`) are wired to the Phase-1/2a endpoints and protected by `RequireAuth`.
`/register` submits `organization` and optional `applicationAnswers`
(`[{key:'why'|'benefit', answer}]`) alongside the required fields; the seed
includes an approved, email-verified demo volunteer (`ERC-1000`) so the
volunteer side is exercisable locally.

Async jobs (BullMQ) and VerificationReference/QR issuance land in later phases;
the tables exist now. Time-request decision updates are plain column updates
(allowed) — only the audit log is append-only.