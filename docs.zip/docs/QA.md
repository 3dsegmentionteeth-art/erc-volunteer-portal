# QA — milestone report log

Format mandated by the project brief. Append a new report after **every**
milestone; answer fields honestly (a "not verified" is a defect if the claim is
made elsewhere).

## Phase 1 — Foundation + base auth (03:xx UTC, 2026-09-22)

### What was implemented

- Project scaffold: `docker-compose.yml` (postgres:16, redis:7, minio),
  `.env.example`, `.gitignore`, multi-stage `server/Dockerfile` +
  `.dockerignore` (Node 20 Alpine, prod-only deps).
- Prisma schema: 12 models + 3 migrations — init; CHECK constraints (roles,
  statuses, email format, signs, required text, document owner XOR) + session
  table + append-only triggers; TRUNCATE guard.
- Auth scaffolding: login/me/logout, Postgres-backed sessions, CSRF
  double-submit (global on /api), argon2id, login slow-down + hard limit,
  audit-worthy auth events, timing-equalized miss path, seed data.

### Automated tests

- Vitest + Supertest integration suite against a real Postgres (`erc_portal_test`,
  created and migrated by a global setup): **31 tests, 31 passed**.
  Coverage: login (admin/volunteer, wrong password, unknown id, malformed body,
  session-id regeneration), CSRF (missing token → 403, token issuance incl.
  httpOnly cookie), /me (auth and unauth), logout (session destroyed in DB,
  subsequent /me 401), authorization middleware (401/403 role, IDOR forged
  owner → 403, branch-scope violation → 403, HQ bypass, expired session),
  rate limiting (4th try 401 → 5th 429 LOGIN_RATE_LIMITED), DB CHECKs (bad
  status, bad email, zero minutes, signed adjustments, empty reason, document
  owner XOR, one-pending-edit-per-record), audit append-only (UPDATE/DELETE/
  TRUNCATE all rejected).
- `npm run build` (tsc) exits clean; `npm audit` = 0 vulnerabilities.

### Manual tests

- `npm run db:seed` seeded branch `ERC-HQ` + `admin`/`branch-admin`.
- Live server (compiled `dist`) exercised with a real HTTP client:
  health 200; csrf token issued; login **without** CSRF → 403; login with CSRF
  → 200 `role=admin isHq=true`; /me → admin; wrong password → 401; logout →
  /me 401; volunteer login (approved row) → 200 `role=volunteer`, branch-scoped;
  unknown user → 401.
- Containerized boot validated: `docker compose --profile app up --build app`
  → migrate deploy "No pending migrations", server listening, health 200, full
  login→/me→logout→401 roundtrip inside the container.

### Security review

- Driven by an external reviewer over `server/src`: 0 critical. Med/high-value
  fixed this phase: CSRF self-heal on stale cookie (`generateToken(req,res,true)`),
  branch-scope fail-closed on missing target, precomputed dummy hash for
  constant-time miss, TRUNCATE guard added, session/CSRF cookie lifetimes
  aligned, `trust proxy` wired to env.
- No secrets committed. `.dockerignore` prevents `.env`/`node_modules` from
  ever entering the build context.

### Bugs found (this phase)

| # | Severity | Status | Summary |
|---|----------|--------|---------|
| 1 | Med | Fixed | `Express.Session` type never existed on the installed typings → compile failure replaced with module augmentation via `req.session?.auth` |
| 2 | Med | Fixed | csrf-csrf 403 fell through to 500 (error name is `ForbiddenError`, not `BadRequestError`) |
| 3 | Med | Fixed | CSRF lockout after secret rotation (token endpoint threw instead of overwriting invalid cookie) |
| 4 | Med | Fixed | `requireBranchScope` accepted a missing branch id (fail-open for one-line endpoints) |
| 5 | Low | Fixed | First login-miss was timing-distinguishable (lazy dummy hash) |
| 6 | Low | Fixed | Audit log could be `TRUNCATE`d (row trigger didn't fire) → statement-level guard |
| 7 | Low | Fixed | Vitest 4.1.11 / deepmerge-ts advisories (upgrades + override) |
| 8 | Low | Fixed | PS5.1 `Invoke-WebRequest` caveat — harness, not product |
| 9 | NIT | Fixed | `findFirst` → `findUnique` on unique volunteer code |

### Bugs fixed & regressions

- Regression check after fixes: full suite re-run 31/31 green; live smoke
  re-verified; container build re-run clean.

### Known limitations (honest)

- Node 25 on the dev machine vs the Node 20 LTS target — validated for both
  (NAPI/musl artifacts); a Node-20 host run of the full test suite is not
  performed here.
- MinIO tag is unpinned in compose (`latest`) — dev only; pin before prod
  (flagged in compose).
- Email delivery is not implemented (email verification is Phase 2).
- No CSP/asset headers yet — the API serves JSON; document/file endpoints
  (Phase 5) will revisit headers.
- Rate-limit keying assumes correct `TRUST_PROXY_HOPS` in prod (documented).

### Files changed

See `git` history — root: `docker-compose.yml`, `.gitignore`, `.env.example`,
`README.md`; `server/` (Dockerfile, .dockerignore, package.json, tsconfig,
prisma schema + 3 migrations + seed, `src/**`, `tests/**`); `docs/` x4.

### Database changes

- 3 migrations applied to `erc_portal` (dev) — same set applied to
  `erc_portal_test` by the test global setup. Volume-backed, survives restarts.

### Deployment notes

- `docker compose up -d` for the DB stack; `--profile app up --build app` for
  the API. Container runs `migrate deploy` then serves on :4000.
- Before any non-local deploy: replace dev secrets, change admin seed password,
  set `TRUST_PROXY_HOPS`, pin MinIO, enforce `secure` cookies (NODE_ENV=production).

### Next task / status

- Phase 1 complete. **Reported back to owner; awaiting go-ahead for Phase 2**
  (registration + approval UI).

## Phase 2a — Volunteer registration + approval workflow (02:xx UTC, 2026-09-22)

### What was implemented

- Public registration endpoint (`POST /api/volunteer/register`) — zod
  full-resolve validation, register rate limiter, branch exists + active,
  email uniqueness, argon2id hashed password, `pending` registration + audit.
- Admin review queue: `GET` list (branch-scoped via the service layer, server
  pagination `page/pageSize≤100`, SQL search across name/email/code), scoped
  `GET` detail.
- Transactional approval: registration → `approved`, `Volunteer` created with
  unique `ERC-<n>` code (next-seen starts at 1000), single-use email-verification
  token issued (sha256 digest only), audit written inside the same tx; 5× retry
  on code collision. Double-approval → 409 `REGISTRATION_ALREADY_DECIDED`,
  cross-branch admin → 403 `BRANCH_SCOPE_VIOLATION`.
- Rejection with required `reason` + audit. Notes are sanitized (passwordHash
  stripped from every serialized shape).
- Email verification lifecycle: `verify-email` (hashed-token match, single-use,
  TTL 24h, rate-limited) and `resend-verification` (volunteer-authed, burns old
  tokens in-tx). No SMTP — raw link logged in dev only (documented limitation).

### Automated tests

- **49 tests, 49 passed** (5 files): Phase-1's 31 + 18 new —
  volunteers integration (16) + registration rate-limit (2).
  New coverage highlights: pending registration + audit + no-hash-leak; CSRF
  403; validation; email conflict; missing/inactive branch; admin-only queue +
  HQ pass-through; scoped pagination + search; detail 404 + cross-branch 403;
  approve → `ERC-1001` created ⇒ new volunteer can log in (full roundtrip);
  double-approve 409; reject + audit; verify single-use + replay + expired all
  400; resend burns the old token. Rate-limit tests assert 4 succeeds then a
  429 `REGISTER_RATE_LIMITED` / `VERIFY_RATE_LIMITED`.
- `npm run build` (tsc) exits clean; `npm audit` = 0 vulnerabilities.

### Manual tests

- Debug probe (temp, deleted after) ran the real approve flow end-to-end on the
  dev stack: admin login, approve a seeded pending registration → 200 with
  code `ERC-1001`, then login as the new volunteer → 200 `role=volunteer`.
- Dev DB `erc_portal` reachable (postgres/redis/minio health-checked before the
  milestone); timeboxed stop: **verification link end-to-end was exercised via
  the integration suite and the dev-log emission path, not via a manual browser
  click** (no SPA/email yet — Phase 2b/3).

### Security review

- Focused review of the new module: tokens stored sha256-hashed and single-use;
  approval is all-or-nothing (volunteer + code + token + audit in one tx);
  branch scope enforced server-side (fail closed) on queue, detail, approve,
  reject; rate limits on register/verify/resend; no password hash or raw token
  ever serialized; CSRF global net applies (tested 403). No new secrets.

### Bugs found (this phase)

| # | Severity | Status | Summary |
|---|----------|--------|---------|
| 1 | Med | Fixed | Test harness: `volunteers.rate-limit.test.ts` statically imported `./helpers` → config singleton evaluated before the low limits env was set, so limits stayed at defaults (no 429). Moved to dynamic import; also made `tests/setup.ts` respect pre-set register/verify limits (`??`, mirroring login) |
| 2 | Med | Fixed | Test harness: `await fetchCsrf(agent)` inlined inside a supertest `.set().post()` chain deterministically yields `CSRF_TOKEN_INVALID` (cookie-jar timing in the chained call). Explicit GET-first two-step everywhere; product flow was verified unaffected by the live probe |
| 3 | Low | Fixed | Test bug: missing `const vAgent = newAgent();` after a refactor → `ReferenceError` in the approve test; re-added |
| 4 | NIT | Fixed | Debug probe file left on disk (`server/debug-login.ts`) — removed |

No product defects found this phase.

### Known limitations (honest)

- SMTP not wired: verification link only surfaces in the dev server log; a
  production deployment without an email path cannot complete verification.
- Manual browser verification of the flow is not possible yet (no frontend);
  coverage is integration tests + the API-level live probe.
- Token is an 8-byte random hex — sufficient against online guessing (rate
  limited), secure-transport-only recommendation applies until email delivery.

### Database changes

- None this phase — schema had `email_verifications` (and the registration
  approval columns) ready since Phase 1. Only DML via the new endpoints.

### Deployment notes

- Same as Phase 1. New env knobs (optional, defaults fine for dev):
  `AUTH_REGISTER_RATE_LIMIT/WINDOW_MS`, `AUTH_VERIFY_RATE_LIMIT/WINDOW_MS`,
  `EMAIL_VERIFICATION_TTL_MS` (see `.env.example`).

### Next task / status

- Phase 2a complete. **Reported back to owner; awaiting go-ahead for Phase 2b**
  (MinIO document upload for registrations + SMTP delivery).

## Phase 2b — Registration documents (MinIO) + email delivery (09:5x UTC, 2026-09-22)

### What was implemented

- Applicant document upload `POST /api/registrations/:registrationId/documents`:
  multipart (`file` + `category` in `photo|id_document|certificate|other`),
  CSRF header works unchanged, multer memory storage, 5 MB cap + MIME allowlist
  (png/jpeg/webp/pdf), 20/15 min per-IP rate limit, only while the registration
  is pending (409 `REGISTRATION_DECIDED` otherwise). DB row written first; on
  MinIO `putObject` failure the row is rolled back. Object key
  `registrations/{registrationId}/{uuid}` (no user filenames ever touch storage).
  Audit `document.uploaded`.
- Applicant deletion of own pending documents
  `DELETE /api/registrations/:registrationId/documents/:documentId` — row removed
  + object removed best-effort; audit `document.deleted`.
- Admin review: `GET /api/admin/registrations/:id/documents` (branch-scoped,
  `?category=` filter), `POST /api/admin/documents/:id/approve` and
  `.../reject` (note), 409 `DOCUMENT_ALREADY_REVIEWED` on double review,
  audits `document.approved` / `document.rejected`, reviewer recorded.
- `GET /api/admin/documents/:id/download-url` → pre-signed URL (default 5 min);
  the bucket stays private and the raw object key is never serialized anywhere.
- Verification emails (2a gap closed): approval now emits the one-time link via
  `lib/mailer.ts` — SMTP when `SMTP_HOST` is set, buffered stream transport in
  tests (`lastCapturedMail()`), log-only dev fallback otherwise; resend reuses
  the same path. Token storage unchanged (sha256, single-use, TTL).

### Automated tests

- **57 tests, 57 passed** (6 files): Phase-2a's 49 + 8 new documents tests.
  Highlights: pending row + MinIO object written + audit + no objectKey leak;
  CSRF 403 on upload; invalid category / MIME / oversize (413
  `FILE_TOO_LARGE`) / missing file; unknown registration 404; decided
  registration 409; applicant deletes own pending doc → row gone + object gone
  + audit; admin list scoped (foreign branch 403 `BRANCH_SCOPE_VIOLATION`) +
  category filter; approve/reject with audit, double review 409, reviewer set;
  pre-signed URL fetch returns the exact uploaded bytes; approve → captured mail
  contains the verify URL → token verifies end-to-end.
- `npm run build` (tsc) exits clean; `npm audit` = 0 vulnerabilities.

### Manual tests

- MinIO bucket `erc-documents-test` auto-created on first use; `docker compose`
  stack health-checked (postgres/redis/minio) before the run. Objects verified
  present/absent via `lib/storage` `objectExists` inside the suite (no UI yet).
- Timeboxed stop: the pre-signed URL + SMTP path are verified at the API/infra
  level with a real MinIO endpoint — no browser/manual email client click (no
  frontend; Phase 3).

### Security review

- Private bucket; the only read path is an admin-issued, time-limited pre-signed
  URL. Objects keyed by unguessable registration id + UUID; original filename
  only a display label on the row (`sanitizeOriginalName`), `Content-Type`
  pinned server-side. Size/MIME gates run before any write. Documents inherit
  the registration's branch → admin review/list/download fail closed (403) on
  mismatch. Acceptable-limitation note added to SECURITY.md: upload attribution
  rests on unguessable id + CSRF + rate limit, not cryptography. verification
  token still sha256-only in the DB; SMTP replaces the dev-log signal in
  production.

### Bugs found (this phase)

| # | Severity | Status | Summary |
|---|----------|--------|---------|
| 1 | Med | Fixed | Sequential `validateParams` calls each replace `req.params`, so two chained validators on the DELETE route dropped `registrationId` → 400. Combined into one `registrationDocumentParamsSchema` |
| 2 | Med | Fixed | `async function uploadDoc(...)` returned a Promise → supertest chaining `.set().expect()` broke. Removed `async` |
| 3 | Low | Fixed | Test CSRF misuse: token fetched on one agent sent on another agent's request → spurious `CSRF_TOKEN_INVALID` instead of the asserted business code in two spots; reused a single agent per flow |
| 4 | Low | Fixed | Mailer capture only handled `string` raw; nodemailer's buffered stream can yield Buffer, and the link is MIME-folded in the raw body. Capture now stores the URL directly (and stringifies raw) |
| 5 | NIT | Fixed | Build/test-time parse error after a bad refactor of `mailer.ts` (stray `}`) — caught by the suite run, fixed |

Product defects: the approve-never-emailed gap (Phase 2a) is the one real one;
fixed here and now covered by a test.

### Known limitations (honest)

- Retried-in-flight structure: multer reads the multipart body before the route
  handler; a client that uploads then fails mid-handler leaves a held connection
  until the request completes — no orphaned objects (row-first rollback).
- Public upload attribution is link-based (see Security review) — acceptable
  now, revisit with signed credentials if the threat model grows.
- No browser/email-client verification yet (no frontend); coverage is
  integration tests + MinIO-level object assertions.
- SMTP is implemented but untested against a live provider in this environment;
  the transport path is exercised via the buffered stream in tests.

### Database changes

- None. The `documents` table (status/category vocab, exactly-one-owner CHECK,
  `branch_id` NOT NULL, `reviewer_id SET NULL` on admin deletion) existed since
  Phase 1 — new endpoints only write DML. Test seeds add a second branch +
  `branch-admin-b`.

### Deployment notes

- New env knobs (optional, dev defaults fine): `DOCUMENT_UPLOAD_RATE_LIMIT`,
  `DOCUMENT_UPLOAD_RATE_WINDOW_MS`, `DOCUMENT_MAX_BYTES`,
  `DOCUMENT_PRESIGNED_TTL_SECONDS`, `DOCUMENT_ALLOWED_MIME_TYPES`, `SMTP_HOST`,
  `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`, `SMTP_SECURE`
  (see `.env.example`). Leave `SMTP_HOST` empty locally to keep the dev-log
  fallback. `document` summary tables unaffected; a `reviewerId` FK links to
  `admins` (SET NULL on admin deletion).

### Next task / status

- Phase 2b complete. **Reported back to owner; awaiting go-ahead for Phase 3**
  (frontend scaffold).

---

# Phase 3 — Verification / Stop-point Report (2026-09-22)

⚠ This is the evidence report the owner requested before any further work
(stop-point). It is **not** a Phase 3 acceptance report. Status headline:
**Phase 3 is PARTIALLY BUILT and PARTIALLY VERIFIED — NOT COMPLETE.** The web
test suite is currently red (9/16). Every claim below is tagged with how it was
verified, or marked NOT VERIFIED.

## Methodology

All runs on 2026-09-22 on this machine. Docker containers postgres/redis/minio
were `running (healthy)` for 42+ minutes (checked via `docker compose ps`)
*before* any test ran. The server suite ran against those live stores — Redis
rate-limit windows, Postgres CHECK/p-limit triggers, MinIO objects — nothing was
mocked or skipped.

## 1. Exact current state — build + test evidence

### Server (`D:\opencode\erc-volunteer-portal\server`)
- `npm run build` → **PASS** (`tsc -p tsconfig.json`, no errors).
- `npx vitest run` → **7 test files · 59 tests · 0 failures** (44.98 s).
  Per file (assertion results):

| File | Tests | Failed |
|---|---|---|
| auth.test.ts | 20 | 0 |
| volunteers.test.ts | 16 | 0 |
| db-constraints.test.ts | 10 | 0 |
| documents.test.ts | 8 | 0 |
| branches.test.ts | 2 | 0 |
| volunteers.rate-limit.test.ts | 2 | 0 |
| auth.rate-limit.test.ts | 1 | 0 |
| **TOTAL** | **59** | **0** |

(Caveat: vitest's JSON reporter under-parses `auth.rate-limit.test.ts` when read
programmatically (returns 0 tests); the console reporter and the summary line
both say 59/59.)
- `npm audit` → 0 vulnerabilities.

### Web (`D:\opencode\erc-volunteer-portal\web`)
- `npm run build` (`tsc -b && vite build`) → **PASS**. dist: index.html 0.74 kB,
  CSS 21.61 kB, JS 345.52 kB (110.02 kB gzip).
- `npm test` (`vitest run`) → **3 test files · 16 tests · 7 passed / 9 failed**
  (30.68 s). Per file:

| File | Tests | Passed | Failed |
|---|---|---|---|
| src/test/client.test.ts | 9 | 5 | 4 |
| src/test/i18n.test.ts | 3 | 2 | 1 |
| src/test/LoginPage.test.tsx | 4 | 0 | 4 |

Root causes (all test-code defects; the product code compiled and the components
rendered correctly in the failure snapshots):

- **client.test.ts (4):** the "caches the CSRF token across mutations" and
  "retries once with a fresh token" cases used `api.logout()` as the dummy
  mutation, but `logout()` deliberately clears the token cache after success —
  the tests' premise ignored that, so the queued mock responses didn't line up
  ("retries" then failed asserting `api.csrfToken === 'fresh-tok'` after logout
  cleared it). The "maps error envelope" and "registerVolunteer omits empty
  optional fields" cases forgot to queue the `csrf-token` preflight response, so
  the client threw `CSRF_FETCH_FAILED` before the asserted request ever ran.
- **i18n.test.ts (1):** "persists the language choice" calls
  `localStorage.getItem('erc-lang')`; in that vitest/jsdom cycle the global
  `localStorage` is not a Storage-shaped object (`getItem is not a function`).
  The other two i18n cases (default en/ltr, ar → rtl + Arabic strings) PASS.
- **LoginPage.test.tsx (4):** exact-string label queries fail because the
  `TextField` label renders `Registered number *` (required-asterisk span) — so
  `getByLabelText('Registered number')` etc. match nothing; the submit button's
  accessible name is `Login` (en.ts `login`), not `Sign in` (`loginTitle`).
  Also emits `act(...)` warnings from the auth provider's async `me()`.

⇒ **Phase 3 is partially done**: server-side support is green, the SPA scaffold
builds clean, but the frontend test suite is red (9/16) and the items in §9 are
missing.

## 2. GET /api/branches — route, test, result

- Route: `server/src/routes/index.ts` mounts `apiRouter.get('/branches',
  branches)` — public, read-only (GET; no auth, no CSRF). Handler in
  `volunteer.controller.ts` `branches` → `volunteer.service.ts` `listBranches()`
  → `volunteer.repository.ts` `listActiveBranches()` (where `isActive=true`,
  orderBy `nameEn`, select `id/code/nameEn/nameAr`; `isActive`/`createdAt` never
  serialized).
- Test: `server/tests/branches.test.ts` — "is public — no auth, no CSRF header
  required" (200, 2 items, total 2) and "returns id/code/nameEn/nameAr and
  excludes inactive branches" (seeds 2 active + 1 inactive).
- Result: **both PASS** in the full suite (evidence: verbose vitest output +
  JSON report).
- Live check (API started for this report): `GET http://localhost:4000/api/
  branches` → `{"items":[{"id":"cmu4thgru0000cnski6w35n0w","code":"ERC-HQ",
  "nameEn":"Headquarters","nameAr":"المقر الرئيسي"}],"total":1}`. Arabic is
  stored correctly; the earlier `?????` in a console print was a PowerShell
  console-encoding artifact, not an API bug.

## 3. Frontend scaffold — what actually exists

- Pages: `src/pages/LoginPage.tsx` (volunteer|admin toggle, localized errors),
  `src/pages/RegisterPage.tsx` (branch dropdown from `/api/branches`, client
  validation, password-match check, success screen), `src/pages/
  DashboardShell.tsx` (welcome, HQ/branch scope line, placeholder module cards,
  logout).
- Routing/state: `src/App.tsx` (`/login`, `/register`,
  `RequireAuth`-wrapped `/`, `*`→`/`), `src/main.tsx`
  (BrowserRouter + StrictMode), `src/auth/AuthContext.tsx` + `RequireAuth.tsx`
  (me-on-mount, loading splash, redirect to `/login`).
- CSRF-aware fetch client: `src/api/client.ts` lazily GETs `/api/auth/csrf-token`
  before the first mutating call, echoes `x-csrf-token`, retries once with a
  fresh token on `CSRF_TOKEN_INVALID`, and swaps in the fresh token returned by
  login (**yes, this is implemented, not just documented**).
- **Token-swap IS exercised by a passing test**: client.test.ts "login() posts
  credentials with a fresh CSRF header and swaps the token" queues `csrf-token →
  tok-1`, then `login → {user, csrfToken: tok-2}`, and asserts the request
  carried `tok-1` and `api.csrfToken === 'tok-2'`. **PASSED.** (The cache +
  retry tests FAIL per §1 for wrong premises — asserting a behavior the client
  never had because logout clears the cache.) A live API login also returned a
  fresh `csrfToken` different from the pre-login token.

## 4. i18n / RTL — real-browser confirmation

- jsdom unit test "switches to Arabic (first-class) and flips the document to
  RTL" **PASSED**: `dir=rtl`, `lang=ar`, `t('loginTitle') === 'تسجيل الدخول'`.
- **Real browser (Playwright, headful at http://localhost:5173 via `vite dev`):**
  load → evaluated `dir=ltr, lang=en`; clicked the language switch →
  `document.documentElement.dir === 'rtl'`, `lang === 'ar'`, `h2` text
  `تسجيل الدخول`, role tabs `متطوع` / `مدير`, submit `تسجيل الدخول`. **RTL
  confirmed rendering in a browser, not just wired up.**
- Console during that session: 2 errors, both the *expected* `401` from
  `/api/auth/me` when unauthenticated (that 401 drives the RequireAuth redirect
  to `/login`). No other errors.
- Minor cosmetic find: the language switch exposes "EnglishEnglish" in the a11y
  tree (the sr-only `t('language')` duplicates the visible label). Harmless;
  noted only.

## 5. Open item A — is document upload gated on a verified email?

**No.** Document upload is still authorized by registration-ID + CSRF + rate
limit alone. Code evidence:

- `server/src/app.ts`: `doubleCsrfProtection` middleware applies to **all**
  mutating `/api` requests globally.
- `server/src/modules/volunteers/document.routes.ts`: `POST
  /api/registrations/:registrationId/documents` → `documentUploadLimiter` →
  `registrationDocumentUpload.single('file')` → `validate(uploadBodySchema)` →
  controller.
- `document.service.ts` `uploadRegistrationDocument`: checks the registration
  exists (404) and `status === 'pending'` (409 if already decided). There is no
  verification token, no email-ownership proof, and no "verified applicant"
  check at upload time — uploads happen *before* approval/email-verification by
  design.
- Verified email enters only later (approve → sends verification; email
  verification gates volunteer *login enablement*, not document upload).
- No test asserts a verified-email requirement (because none exists). The
  documents suite covers CSRF/MIME/size/404/409/ownership instead. This is the
  limitation already documented in SECURITY.md ("Registration documents").

## 6. Open item B — what `getSessionIdentifier: () => ''` does

csrf-csrf's double-submit mixes `getSessionIdentifier()` into token generation to
scope tokens per session. Returning `''` makes that component constant, so any
issued token is valid for any session **as long as the browser also sends the
csrf cookie** (httpOnly, SameSite=Lax, expires at sessionMaxAgeMs).

**What it protects against:**
- Classic cross-site CSRF: an attacker page can't read the token (SOP — can't
  read the httpOnly cookie or app responses), can't guess it (size 64 →
  512-bit), and can't set `x-csrf-token` (custom headers need a preflighted
  fetch the attacker can't complete without the token); SameSite=Lax blocks
  top-level cookie-following on cross-site POSTs. Forged requests → 403.
- Session-fixation friction: because the token survives `session.regenerate()`
  on login, login doesn't strand every client with a dead token (the app also
  swaps tokens from the login response).

**What it does NOT protect against:**
- Malicious same-origin script (XSS): XSS can call the API same-origin and read
  the in-memory token — CSRF is irrelevant once XSS exists.
- Same-site attackers (compromised subdomain, same-site XSS, MITM without TLS).
- Cross-session/same-host reuse: because the identifier is constant, a leaked
  token for session A remains usable for session B (the cookie is the real gate;
  the token alone proves nothing). Logout destroys the server session but the
  csrf cookie only expires at `sessionMaxAgeMs`, so a stale token+cookie pair is
  reusable by anything that can already send it — again only same-site/XSS.
- Authenticating *who* sent the request: it only proves "a browser holding this
  app's cookies set this header", not "the logged-in user sent this". Real
  authorization lives in the session + branch-scope layer.

Net: `''` trades per-session token scoping for login-survivability. Residual
risks are XSS/same-site/MITM — outside csrf-csrf's design envelope. A stronger
posture would add an Origin/Referer allow-list middleware and cookie hardening;
not needed for the current threat model, worth a future ticket. (Empirical note:
no test exercises cross-session token reuse, so that specific behavior is
inferred from csrf-csrf's composition, not proven by a run — see §9.)

## 7. Environment / compose state

- `docker compose ps` (2026-09-22): `minio` (9000-9001), `postgres` (5432),
  `redis` (6379) all `running (healthy)`, up 42 min. **No `app`/`web` compose
  service** exists; the API server was *not* running when the stop-point was
  reached.
- The server suite ran against those live stores (nothing mocked/skipped).
- For this report only, I started `npm run dev` in server (→ :4000) and web
  (→ :5173); verified live `/api/branches`, the CSRF→login round-trip, and that
  the vite proxy forwards `/api` → :4000 (the unauthenticated `401` on `/me`
  proves proxy + real session check work).

## 8. Changes made while gathering evidence (disclosed)

1. `web/package.json` dependency pins corrected — `i18next ^24.2.4` →
   `^26.4.2`, `react-i18next ^15.4.1` → `^17.0.15`,
   `i18next-browser-languagedetector ^8.1.0` → `^8.2.1`. **The old pins were
   wrong**: npm resolved `i18next@24.2.4` to `404 No match found` (the 24 line
   ends at 24.2.3), so `npm install` could not run at all until corrected.
   Current registry line is i18next 26.4.2 / react-i18next 17.0.15.
2. `web/src/test/LoginPage.test.tsx` import path fixed: `./LoginPage` →
   `../pages/LoginPage` (the original path didn't exist; tsc rejected it — a
   typo, not a design change).

No product/behavioral code changed to produce this report.

## 9. VERIFIED / NOT VERIFIED matrix

| Field | Status |
|---|---|
| Server build (tsc) | VERIFIED — PASS |
| Server suite (59/59, 7 files, real infra) | VERIFIED |
| Server `npm audit` (0) | VERIFIED |
| Web build (`tsc -b && vite build`) | VERIFIED — PASS |
| Web suite (16) | VERIFIED — 7 pass / 9 fail, root causes in §1 |
| Web deps install | VERIFIED — 174 pkgs, 0 vulnerabilities (after pin fix) |
| GET /api/branches (route + 2 tests + live fetch) | VERIFIED |
| CSRF client + login token-swap test | VERIFIED — swap test PASSES; retry/cache tests FAIL on wrong premises |
| Login/Register/Dashboard pages exist | VERIFIED (files + tsc) |
| i18n en/ar resources | VERIFIED — 2/3 jsdom tests; 1 fails on `localStorage` |
| RTL in a real browser | VERIFIED (Playwright: dir=rtl, lang=ar, Arabic strings) |
| Live admin login (CSRF→login→fresh token) | VERIFIED (curl round-trip) |
| Upload requires verified email | VERIFIED ABSENT — still id + CSRF + rate limit (code + test set) |
| `getSessionIdentifier: ''` semantics | VERIFIED against csrf-csrf composition; cross-session reuse NOT VERIFIED (no test) |
| Volunteer-code live login, SPA logout, dashboard nav | NOT VERIFIED — no browser flow past the login page (only jsdom/curl/units) |
| Register page branch dropdown in a browser | NOT VERIFIED — endpoint + client unit tested only |
| SMTP delivery to a live provider | NOT VERIFIED — buffered-stream test only |
| Pre-signed URL in a real browser | NOT VERIFIED — API-level only |
| Web Dockerfile / `.dockerignore` / compose `web` service | NOT VERIFIED — does not exist yet |
| Phase-3 docs (PLAN/ARCHITECTURE/README) | NOT VERIFIED — not updated yet |

## Status / next task

Phase 3 is **partial and red on the frontend**. Recommended stop-point decisions
before any further work: (1) fix the 9 frontend test failures (test-code only —
root causes identified in §1) and get the web suite green; (2) complete the
missing deliverables — web Dockerfile/.dockerignore, compose `web` service, docs
updates; (3) re-verify the NOT VERIFIED rows; then re-report for go-ahead.

No further building or changing was done after the stop-point instruction.

## Phase 3 — Frontend scaffold: final report (11:20 UTC, 2026-09-22)

Follow-up to the stop-point report above. The three recommended stop-point
decisions were executed; the web suite went green, the SPA was containerized,
the full stack was verified in a real browser, and two real bugs were found and
fixed. Everything below was verified after those changes.

### What was completed (post stop-point)

- **Web tests fixed** (test-code only, root causes from §1): hermetic
  `localStorage` polyfill in `setup.ts` (Node's experimental webstorage shadows
  jsdom's — job warning `--localstorage-file was provided without a valid
  path`); client tests re-aimed at the real contract (`registerVolunteer` then
  logout clears the CSRF cache; `csrf-token` preflight queued before mutations;
  envelope/omit-empty assert on replayed calls); i18n persistence test uses the
  synchronous `setLanguage`; LoginPage :label queries regexed (`*` suffix) and
  submit name is `Login`. Web suite **16 → 17 red 0** (the 17th is the new boot
  regression test, below).
- **Real bug #1 — Arabic-first boot left `<html>` in English/LTR**: with
  `erc-lang=ar` persisted, the login page rendered Arabic with
  `lang="en" dir="ltr"`. Root cause: **i18next v26 can resolve `init()` while
  still emitting its async events or (with inline resources + sync detection)
  before a late-attached listener** — the boot language is never re-emitted, so
  the old `'initialized'`/`'languageChanged'`-only sync never ran for it. Fixed
  in `web/src/i18n/index.ts` by applying the document attributes from the
  resolved `init()` promise (`i18n.language ?? 'en'`) plus keeping the
  `languageChanged` listener; verified by browser (first-load Arabic →
  `lang="ar" dir="rtl"`, English toggle → `ltr`) and by a new regression test
  (`i18n-boot.test.ts`). The earlier hypothesis ("initialized passes `t`,
  not the language" — §1) was wrong as stated; fixed hypothesis above does not
  depend on that signature.
- **Web containerization**: `web/Dockerfile` (Node 24 Alpine build + runner;
  runner copies build-stage `node_modules`, `dist`, `vite.config.ts`; CMD
  `vite preview --host 0.0.0.0`), `web/.dockerignore`, compose `web` service
  enabled (`--profile app`, `ERC_PREVIEW_PROXY_TARGET: http://app:4000`, port
  `127.0.0.1:5173`). `vite.config.ts` `preview.proxy` does `/api` same-origin —
  session/CSRF cookies stay same-site, so **no CORS surface** (a container run
  without the config file had no proxy → `/api` answered the SPA HTML; fixed by
  shipping the file into the runner).
- **Real bug #2 — API container crash-loop (never run before this phase)**:
  `Error: Cannot find module '.../stream-json/src/jsonl/Parser.js'`. The
  `overrides: stream-json@3.7.0` entry in `server/package.json` had silenced the
  Phase-2b advisory but 3.7.x is **ESM with lowercase file names**, while
  `minio@8.0.7` requires CJS `stream-json/jsonl/Parser.js` (capital P). Windows
  host (case-insensitive) worked; the Linux container crash-looped. Fix: removed
  the override (`stream-json@1.9.1` nests under minio, CJS path intact), runner
  copies the full build-stage `node_modules` (an `npm ci --omit=dev` pruning run
  had dropped a prod-required package), both images bumped **Node 20 → 24 LTS**
  (`require(esm)` needs on new Node for the CJS-minio path is moot, and 24 is
  current LTS). Server suite re-greened 59/59 after the change.

### Verification matrix (final)

| Field | Result |
| ------------------ | ---------------------- |
| Server suite (59/59) after dependency change | VERIFIED |
| Web suite (17/17) | VERIFIED |
| Web build (`vite build`) | VERIFIED — PASS |
| `docker compose --profile app` config validity | VERIFIED |
| Stack boots: app `:4000` ("listening"), web `:5173` | VERIFIED |
| `/api/branches` through the API **container** | VERIFIED (HQ branch) |
| `/api/auth/csrf-token` through the web proxy | VERIFIED (real token) |
| First-load Arabic → `lang="ar" dir="rtl"` (browser) | VERIFIED |
| Language switch flips `dir` (browser) | VERIFIED |
| Anonymous `/` → `/login` (RequireAuth) | VERIFIED |
| Admin wrong password → alert "Incorrect identifier or password." | VERIFIED |
| Admin valid login → dashboard "Welcome, Headquarters Administrator" | VERIFIED |
| Logout → `/login`, session cleared | VERIFIED |
| Register page branch dropdown from live API | VERIFIED (Headquarters) |
| Volunteer live login | NOT VERIFIED — no volunteer row in seed |
| SMTP delivery to a live provider | NOT VERIFIED — buffered-stream test only |
| Pre-signed URL in a real browser | NOT VERIFIED — API-level only |

### Disclosures / decisions

- **Two real bugs found and fixed** above (i18n boot attrs; minio/stream-json
  container crash) — neither would have surfaced without container + browser
  verification.
- **`npm audit` (server) is now 2 moderate** (`stream-json <=3.4.0`,
  GHSA-528h-pc64-c93x via `minio@8.0.7`) — the Phase-2b "0" was an artifact of
  the removed, container-breaking override. The advisory's path is MinIO's
  S3-Select JSON parser, **never called by the product**; `npm audit fix
  --force` would downgrade to `minio@7.1.3` (breaking). Decision: **accept and
  document** (docs/SECURITY.md) — re-open when minio ships a patched
  `stream-json` line.
- Docs updated: IMPLEMENTATION_PLAN (Phase 3 ✅), ARCHITECTURE (topology with
  proxy, Node 24 LTS, frontend section), README (compose profile, web testing),
  SECURITY.md (dependency narrative).
- Fabricated pin `i18next@24.2.4` (from §1) was replaced with the installed
  `^26.4.2`; the test import mistype `./LoginPage` → `../pages/LoginPage` and
  the minio/stream-json override were the real causes of the "air-dep 404" and
  container crash respectively — all disclosed.

### Status / next task

Phase 3 **complete and green** (server 59/59, web 17/17, containers up, browser
verified). Next: Phase 4 (volunteer dashboard). Volunteer live login remains
unverifiable until Phase 4 seeds or registers a volunteer account; SMTP
live-provider and in-browser presigned-URL checks are deferred to Phase 6/7.

## Phase 3.1 — Follow-up close-out (12:10 UTC, 2026-09-22)

Round requested before Phase 4: (1) close the document-upload authorization gap
with an application-access token, (2) confirm/fix the Register page
Organization + application answers, (3) seed a volunteer and verify live login.

**Item 1 — application-access token (server).** New `ApplicationAccessToken`
model (sha256 `token_hash` only, `expires_at`, `used_at`, cascade delete,
migration `20260922120000_application_access_tokens`). `registerVolunteer`
issues 32 random bytes and emails the raw token (`sendApplicationAccessEmail`,
additive `CapturedMail.type`); upload/delete now verify it with DISTINCT 403s
(`APPLICATION_ACCESS_TOKEN_MISSING` / `_INVALID` / `_EXPIRED`). Single-use is
**lifecycle-scoped** — one token per registration, burned atomically in the
approve/reject transaction so it can never outlive a decision (post-decision
reuse → 409 `REGISTRATION_DECIDED`), but **not** per HTTP request so one emailed
link can still attach multiple documents (photo + id + certificate). This
deliberate reading of "single-use" is documented in SECURITY.md §Registration
documents and ARCHITECTURE §9. Tests: documents suite extended with 3 new
token-gating tests; `mkRegistration` now returns `{registrationId, token}`
captured from the stream-buffered mail; test setup bumps
`DOCUMENT_UPLOAD_RATE_LIMIT` (suite uploads exceed the 20/15-min prod default).

**Item 2 — Register page (web).** Confirmed `organization` was already rendered
+ submitted; added the two application-question fields ("Why do you want to
volunteer with the Red Crescent?" / "What do you hope to gain from
volunteering?"), submitted as `applicationAnswers` with keys `why`/`benefit`
(mirroring the reference prototype's profile `saveProfile` keys), empties
omitted; i18n `en`/`ar` keys; `VolunteerRegistrationInput.applicationAnswers`.
New `RegisterPage.test.tsx` (3 tests) + client round-trip test. Browser:
submitted a real registration; row verified in the DB with `organization` and
`applicationAnswers` persisted.

**Item 3 — seeded volunteer.** `prisma/seed.ts` now upserts an approved +
email-verified demo volunteer (`ERC-1000`, password `volunteer-pass-123`,
branch ERC-HQ, organization + answers populated) — dev-only, documented in
SECURITY.md. Live-browser login verified (see matrix).

### Verification matrix (Phase 3.1)

| Field | Result |
| ------------------ | ---------------------- |
| Server suite (62/62) + `tsc` build | VERIFIED |
| Web suite (21/21) + `vite build` | VERIFIED |
| Application-access token: valid token → upload/deploy 201/200 | VERIFIED (suite) |
| Access token: missing → 403 `APPLICATION_ACCESS_TOKEN_MISSING` | VERIFIED (suite) |
| Access token: forged / cross-registration → 403 `APPLICATION_ACCESS_TOKEN_INVALID` | VERIFIED (suite) |
| Access token: expired (expires_at backdated) → 403 `APPLICATION_ACCESS_TOKEN_EXPIRED` (upload + delete) | VERIFIED (suite) |
| Access token burned at approve → reuse 409 `REGISTRATION_DECIDED`, `used_at` set | VERIFIED (suite) |
| CSRF / bad category / MIME / oversize / missing-file upload checks (regression) | VERIFIED (suite) |
| Register page renders organization + 2 question fields (browser) | VERIFIED |
| Register submit persists `organization` + `applicationAnswers` (DB) | VERIFIED |
| Seed adds `ERC-1000` approved + email-verified volunteer | VERIFIED (db:seed) |
| Volunteer live login `ERC-1000` → dashboard "Welcome, Demo Volunteer" | VERIFIED (browser) |
| `/api/auth/me` shape: role `volunteer`, `branchId` set, `isHq: false` | VERIFIED (browser) |
| Volunteer logout → `/login`, session cleared | VERIFIED (browser) |
| SMTP live-provider delivery | NOT VERIFIED — buffered-stream + container log only |

### Disclosures / decisions

- The register-answers **keys `why`/`benefit`** mirror the reference prototype
  (`public/app.js` `saveProfile` fields `answer_why`/`answer_benefit`); the
  reference's register form does not collect them — Phase 1 extended the
  contract to include `applicationAnswers` per the original spec.
- **Single-use semantics** interpreted as registration-lifecycle-scoped (see
  above) so multi-category upload from one emailed link keeps working; the
  runtime grants no second redemption after a decision. Deviation is on the
  record in SECURITY.md.
- Order of checks preserved: unknown registration → 404, decided → 409, then
  token → distinct 403s (no state/attribution leak).
- Docs updated: SECURITY.md (§Registration documents rewritten, seed-PW note),
  ARCHITECTURE.md (§9 + frontend note), QA.md (this report).

### Status / next task

Phase 3 follow-ups **complete**: server 62/62 + build, web 21/21 + build,
migration applied, containers rebuilt and green, browser-verified (register
fields → DB; volunteer login/me/logout). Ready to continue to Phase 4 —
volunteer dashboard.