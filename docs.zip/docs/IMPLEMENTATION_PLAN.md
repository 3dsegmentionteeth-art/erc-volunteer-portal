# Implementation Plan

Milestone-driven build. Every milestone ends with a QA report (docs/QA.md) and
honest reporting — we never claim something is done without manual + automated
verification against a real running stack.

## Phase 1 — Foundation + base auth ✅ (this phase)

- [x] Project scaffold, `.env.example`, docker-compose (postgres/redis/minio).
- [x] Prisma schema (12 models) + migrations (init, CHECK constraints +
  session table + append-only triggers, TRUNCATE guard).
- [x] Auth scaffolding: login / me / logout, CSRF, rate limiting, Postgres
  sessions, argon2id, audit-worthy events, seed (HQ branch + HQ + branch admin).
- [x] Vitest + Supertest integration suite (31 tests) against real Postgres.
- [x] Docs (ARCHITECTURE/SECURITY/QA), README, multi-stage Dockerfile, live
  smoke test, containerized boot validation.

## Phase 2 — Volunteer registration + branch/approval

### 2a — Registration + approval workflow ✅ (this phase)

- [x] Public registration endpoint (`POST /api/volunteer/register`, zod input
  validation, rate-limited, email conflicts rejected, branch exists+active).
- [x] Admin review queue (`GET /api/admin/registrations`, branch-scoped,
  server-side pagination + search on name/email/code).
- [x] Transactional approval: creates the Volunteer with a unique `ERC-<n>`
  code (next-seen int starts at 1000) + writes audit in the same tx; branch
  scope enforced (403 `BRANCH_SCOPE_VIOLATION`), double-approval → 409
  `REGISTRATION_ALREADY_DECIDED`.
- [x] Reject with audit (`reason` required).
- [x] Email verification tokens: issued on approval, hashed (sha256) single-use
  rows, TTL `EMAIL_VERIFICATION_TTL_MS` (24h), `POST /api/volunteer/verify-email`
  rate-limited, `POST /api/volunteer/resend-verification` burns old tokens.
  No SMTP yet — dev logs the link (SMTP = Phase 2b/7).
- [x] Tests: volunteers integration (16) + rate-limit (2); full suite 49/49
  (Phase 1's 31 + 18 new). Build + `npm audit` clean. QA report appended.

### 2b — Documents upload (MinIO) + email delivery ✅

- [x] Applicant document upload: `POST /api/registrations/:registrationId/documents`
  (multipart, CSRF header works, 5 MB cap, MIME allowlist
  png/jpeg/webp/pdf, `photo|id_document|certificate|other` category, 20/15min
  per-IP limit), only while the registration is still pending (409 otherwise).
  Object key `registrations/{registrationId}/{uuid}`; DB row written first,
  MinIO `putObject` on failure rolls the row back; audit `document.uploaded`.
- [x] Applicant deletion of own pending documents
  (`DELETE /api/registrations/:registrationId/documents/:documentId`), removes
  the MinIO object best-effort; audit `document.deleted`.
- [x] Admin review: `GET /api/admin/registrations/:id/documents` (branch-scoped,
  category filter), `POST /api/admin/documents/:id/approve` and
  `.../reject` (note), no double review (409 `DOCUMENT_ALREADY_REVIEWED`),
  audits `document.approved` / `document.rejected`.
- [x] `GET /api/admin/documents/:id/download-url` — time-limited pre-signed URL
  (bucket stays private), minutes-scale TTL.
- [x] Verification emails: SMTP delivery (`SMTP_*` envs), stream transport in
  tests, log-only dev fallback; approve now emits the link (2a gap fixed),
  resend reuses the same path. One-time hashed token unchanged. Seed:
  admin `branch-admin` / `branch-admin-b`.
- [x] Tests: documents integration (8) exercising upload/validation/403/409/
  404, ownership delete + object removal, admin scope + review + audit,
  pre-signed URL round-trip, approve → captured mail → token verifies. Full
  suite 57/57. Build + `npm audit` clean (0). QA report appended.

## Phase 3 — Frontend scaffold (React + TS + Vite) ✅ (this phase)

- [x] Vite SPA with ERC brand tokens, API client on top of the Phase-1 endpoint
  contracts (global double-submit CSRF via `x-csrf-token` + cookie session),
  i18n (i18next; Arabic first-class + RTL), auth pages wired to login/me/logout/
  register + branches.
- [x] Web test suite (17 tests): hermetic `localStorage` polyfill in setup
  (Node's experimental webstorage shadows jsdom), client (CSRF/retry/envelope/
  omit-empty), i18n (persistence + boot regression), LoginPage (roles, error
  banner, links). 9 red → all green; `npm run build` clean.
- [x] Containerized SPA: `web/Dockerfile` (Node 24 Alpine, `vite preview` +
  same-origin `/api` proxy → `app:4000` via `ERC_PREVIEW_PROXY_TARGET`),
  `web/.dockerignore`, compose `web` service on `127.0.0.1:5173` behind
  `--profile app`. No CORS changes — the proxy keeps session/CSRF cookies
  same-site.
- [x] Real browser verification (Playwright, full container stack): `/` guarded
  to `/login` when anonymous; admin login wrong-password → "Incorrect identifier
  or password." alert; correct login → dashboard ("Welcome, Headquarters
  Administrator"); logout → `/login`; register page branch dropdown populated
  from the live API.
- [x] Real bug fixed: an Arabic-first visit rendered Arabic text while `<html>`
  stayed `lang="en" dir="ltr"`. Root cause: i18next v26 can resolve `init()`
  synchronously (inline resources + sync detection) and does not re-emit
  `initialized`/`languageChanged` with the boot language. Fixed by applying the
  document attributes from the resolved `init()` promise (+ `languageChanged`
  listener); regression test added (17th).
- [x] Server container bug fixed (found only when the container first ran):
  the `stream-json: 3.7.0` npm override was a latent breakage — 3.7.x is ESM
  with lowercase file names, while `minio@8.0.7` does a CJS
  `require("stream-json/jsonl/Parser.js")` (capital P); it worked on the
  case-insensitive Windows host and crash-looped the Linux container.
  Override removed → stream-json@1.9.1 nested under minio. Runner now copies the
  build stage's full `node_modules` (npm dev-pruning dropped a prod-required
  package). Both images bumped to Node 24 LTS.
- Server suite 59/59 and web suite 17/17 after the changes; `docker compose
  --profile app up -d --build` boots app (:4000) + web (:5173) verified
  end-to-end through a real browser.
- Remaining not-verifiable locally: volunteer login (seed has no volunteer
  account), SMTP live delivery, pre-signed URL opened in a real browser —
  documented in the QA report, not silently claimed.

## Phase 4 — Volunteer dashboard

- Service-time records view (approved only; computed totals server-side),
  add/edit time requests with optional assigned admin, request status
  tracking.

## Phase 5 — Admin time management + reports

- Time-request decision (add/edit) with no-double-approval guarantees,
  admin direct adjustments (reason required), onboarding completion dashboard
  (server-computed; never 100% while data is missing), search focus stabi-
  lity, dashboard "Add Time" shortcut, School→Organization naming carried over.

## Phase 6 — Audit, reports, QR verification

- Audit-log viewer (append-only), service reports with opaque verification
  references, QR payloads carry the bare token only.

## Phase 7 — Hardening + release

- Pin container tags, CDN/offline-free image deps review, load-testing,
  Playwright E2E, secrets rotation, deploy runbook.

## Timing / risks

- Node 25 on the dev machine (targets: fine via NAPI argon2 + Prisma 6.19);
  containers run Node 24 LTS (image base bumped in Phase 3 — validated by
  `docker compose --profile app up --build`). Version pins: Node must stay on
  an LTS line for Alpine NAPI/musl prebuilds.
- Docker Desktop must be running for DB-dependent work: `docker compose up -d`
  after any restart.